import numpy as np

x = np.zeros((16, 10))
for i in range(10):
    x[:,i] = i
y = np.zeros((4, 4))
for i in range(4):
    for j in range(4):
        y[i][j] = x[i*j][3]
print(y)

img0 = np.zeros((28, 280))
print(img0[:,9*28:10*28].shape)
